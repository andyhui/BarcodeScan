package com.norinco.device;

import android.app.Activity;
import android.os.Bundle;

public class faultlist extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

}
