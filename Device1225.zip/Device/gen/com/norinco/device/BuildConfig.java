/** Automatically generated file. DO NOT MODIFY */
package com.norinco.device;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}